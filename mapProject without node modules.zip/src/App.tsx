import React from 'react';
import Map from './components/map';
import './App.css';

function App() {
  return (
    <main>
      <Map/>
    </main>
  );
}

export default App;
